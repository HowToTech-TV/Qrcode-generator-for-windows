import tkinter as tk
import os
import time
from tkinter import messagebox as msg
import webbrowser
from PIL import Image
try:
  import qrcode
except ModuleNotFoundError:
  base4 = tk.Tk()
  base4.withdraw()
  msg.showerror("Error", "The qrcode module is not installed.")
  base4.mainloop()
  pass
else:
  import qrcode
base = tk.Tk()
base.title("QRCode Generator Version 1.0(Github Version)")
base.geometry("500x400")
base.config(bg="White")
label = tk.Label(base, text = "Qrcode Generator", bg="white", font = ("Segoe UI Bold",30)).pack()
label = tk.Label(base, text = "Please enter the link you want to convert:", bg="white", font = ("Segoe",15)).pack()
link = tk.StringVar()
link.set('http://www.google.com')
entry = tk.Entry(base, textvariable=link).pack(padx=40)
label = tk.Label(base, text = "Please enter the Filename:", bg="white", font = ("Segoe",15)).pack()
name = tk.StringVar()
name.set('google')
entry1 = tk.Entry(base, textvariable=name).pack(padx=40)
def generate():
    if link.get() == '':
        msg.showerror("Error!", "Please input a link!")
    elif name.get() == '':
        msg.showerror("Error","Please input a filename!")
    else:
        qr = qrcode.QRCode(version=1, box_size=10,border=5)
        qr.add_data(link.get())
        qr.make(fit=True)
        img = qr.make_image(fill_color = "black",back_color="white")
        print("Preparing image: qrcode_{}.png".format(name.get()))
        time.sleep(8)
        for i in range(100):
            print("Loading...",i,"%")
            time.sleep(0.2)
        print("Waiting...")
        time.sleep(11)
        print("Saving...")
        time.sleep(11)
        img.save("qrcode_{}.png".format(name.get()))
        msg.showinfo("Completed","Completed. Image saved in {}\qrcode_{}.png.".format(os.getcwd(), name.get()))
        imgpath = os.getcwd() + "\\qrcode_{}.png".format(name.get())
        image = Image.open(imgpath)
        image.show()
button = tk.Button(base, text="Generate QRCode", command = generate, font = ("Segoe",15)).pack()
def exit():
    base.destroy()
def git():
    webbrowser.open("http://github.com/HowToTech-TV/")
def root():
    msg.showinfo("INFO","Root Window")
def report():
    webbrowser.open("https://github.com/HowToTech-TV/Qrcode-generator-for-windows/issues")
def viewrepo():
    webbrowser.open("http://github.com/HowToTech-TV/Qrcode-generator-for-windows")
def faq():
    base2 = tk.Tk()
    base2.title("FAQ")
    base2.geometry("900x900")
    base2.config(bg = "white")
    label = tk.Label(base2, text = "Frequently asked questions", bg="white", font = ("Segoe UI Bold",25)).pack()
    label2 = tk.Label(base2, text = "1. Where can my find my image?", bg="white", font = ("Segoe UI Bold",15)).pack()
    label3 = tk.Label(base2, text = '''The image stored in your current directory. If you want to \n know where is your current directory, type:\n dir \n in cmd or type :\n import os \n print(os.getcwd()) \n in python Console.''', bg="white", font = ("Segoe",11)).pack()
    label4 = tk.Label(base2, text = "2. Why the console always show ModuleNotFoundError?", bg="white", font = ("Segoe UI Bold",15)).pack()
    label5 = tk.Label(base2, text = '''Qrcode is not a bulit-in module. You should install it manually. You should type this in the cmd: \n pip install qrcode\n to install the package.''', bg ="white", font = ("Segoe",11)).pack()
    button = tk.Button(base2, text = "Report a Bug or Error", command = report).pack()
    base2.mainloop()
def yt():
    webbrowser.open("https://youtube.com/channel/UCQDOdxPg3BXJjY0EWNMJgpQ")
def about():
    base3 = tk.Tk()
    base3.title("About QrcodeGenerator")
    base3.geometry("300x300")
    base3.resizable(False,False)
    label1 = tk.Label(base3, text = "Qrcode Generator", font = ("Segoe",20)).pack()
    label2 = tk.Label(base3, text = "Version 1.0").pack()
    label3 = tk.Label(base3, text = "2021 HowToTech TV. ")
    button = tk.Button(base3, text = "View repository on github.com", command=viewrepo).pack()
    base3.mainloop()
    
    
    
    
menu = tk.Menu(base)
menubar = tk.Menu(menu)
filemenu = tk.Menu(menubar, tearoff=0)
menubar.add_cascade(label = "File", menu=filemenu)
filemenu.add_command(label = "Visit My Github Page", command=git)
filemenu.add_command(label = "Visit my youtube channel",command=yt)
filemenu.add_separator()
filemenu.add_command(label = "Exit", command=exit)
windowmenu = tk.Menu(menubar, tearoff=0)
menubar.add_cascade(label = "Window", menu = windowmenu)
windowmenu.add_command(label = "{Root}", command=root)
helpmenu = tk.Menu(menubar, tearoff=0)
menubar.add_cascade(label = "Help", menu = helpmenu)
helpmenu.add_command(label = "FAQ", command = faq)
helpmenu.add_separator()
helpmenu.add_command(label = "About", command = about)
base.config(menu=menubar)









base.mainloop()
